package io.github.gaming32.literalskyblock.client;

import org.joml.Matrix4f;
import io.github.gaming32.literalskyblock.SkyBlock;
import io.github.gaming32.literalskyblock.SkyBlockEntity;
import io.github.gaming32.literalskyblock.VoidBlockEntity;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_5614;
import net.minecraft.class_765;
import net.minecraft.class_827;

public class SkyBlockEntityRenderer implements class_827<SkyBlockEntity> {
    public SkyBlockEntityRenderer(class_5614.class_5615 context) {
    }

    @Override
    public void render(SkyBlockEntity entity, float tickDelta, class_4587 poseStack, class_4597 source, int light, int block) {
        if (!entity.method_11010().method_11654(SkyBlock.ACTIVE)) return;
        final Matrix4f matrix4f = poseStack.method_23760().method_23761();
        final boolean solid = LSBClient.needIrisCompat && IrisCompat.shadersEnabled();
        renderCube(entity, matrix4f, source.getBuffer(
                solid
                        ? class_1921.method_23577()
                        : entity instanceof VoidBlockEntity
                        ? class_1921.method_34571()
                        : LSBClient.SKY_RENDER_TYPE
        ), solid);
        LSBClient.updateSky = true;
    }

    private void renderCube(SkyBlockEntity entity, Matrix4f matrix, class_4588 buffer, boolean block) {
        renderFace(entity, matrix, buffer, 0.0f, 1.0f, 0.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, class_2350.field_11035, block);
        renderFace(entity, matrix, buffer, 0.0f, 1.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, class_2350.field_11043, block);
        renderFace(entity, matrix, buffer, 1.0f, 1.0f, 1.0f, 0.0f, 0.0f, 1.0f, 1.0f, 0.0f, class_2350.field_11034, block);
        renderFace(entity, matrix, buffer, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 1.0f, 1.0f, 0.0f, class_2350.field_11039, block);
        renderFace(entity, matrix, buffer, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 1.0f, class_2350.field_11033, block);
        renderFace(entity, matrix, buffer, 0.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 0.0f, 0.0f, class_2350.field_11036, block);
    }

    private void renderFace(SkyBlockEntity entity, Matrix4f matrix, class_4588 buffer, float f, float g, float h, float i, float j, float k, float l, float m, class_2350 direction, boolean block) {
        if (entity.shouldRenderFace(direction)) {
            addVert(entity, buffer, matrix, f, h, j, direction, block);
            addVert(entity, buffer, matrix, g, h, k, direction, block);
            addVert(entity, buffer, matrix, g, i, l, direction, block);
            addVert(entity, buffer, matrix, f, i, m, direction, block);
        }
    }

    // Nowy system w 1.21: wymusza kolejność budowania wierzchołka i eliminuje endVertex()
    private void addVert(SkyBlockEntity entity, class_4588 consumer, Matrix4f matrix, float x, float y, float z, class_2350 direction, boolean block) {
        consumer.method_22918(matrix, x, y, z);
        if (block) {
            if (entity instanceof VoidBlockEntity) {
                consumer.method_1336(25, 25, 51, 255);
            } else {
                consumer.method_1336(120, 167, 255, 255);
            }
            consumer.method_22913(0f, 0f);
            consumer.method_60803(class_765.field_32767);
            consumer.method_22914((float)-direction.method_10148(), (float)-direction.method_10164(), (float)-direction.method_10165());
        }
    }

    @Override
    public int method_33893() {
        return 256;
    }
}