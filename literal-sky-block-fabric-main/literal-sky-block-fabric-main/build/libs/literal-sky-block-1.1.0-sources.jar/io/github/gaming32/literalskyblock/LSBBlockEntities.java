package io.github.gaming32.literalskyblock;

import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class LSBBlockEntities {
    public static final class_2591<SkyBlockEntity> SKY_BLOCK = class_2378.method_10230(
            class_7923.field_41181,
            class_2960.method_60655(LiteralSkyBlock.MOD_ID, "sky_block"),
            class_2591.class_2592.method_20528(SkyBlockEntity::new, LSBBlocks.SKY_BLOCK).method_11034(null)
    );
    public static final class_2591<VoidBlockEntity> VOID_BLOCK = class_2378.method_10230(
            class_7923.field_41181,
            class_2960.method_60655(LiteralSkyBlock.MOD_ID, "void_block"),
            class_2591.class_2592.method_20528(VoidBlockEntity::new, LSBBlocks.VOID_BLOCK).method_11034(null)
    );

    static void register() {}
}