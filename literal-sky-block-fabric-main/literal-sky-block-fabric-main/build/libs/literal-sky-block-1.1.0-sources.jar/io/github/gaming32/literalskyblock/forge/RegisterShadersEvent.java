package io.github.gaming32.literalskyblock.forge;

import com.mojang.datafixers.util.Pair;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_5912;
import net.minecraft.class_5944;

public class RegisterShadersEvent {
    private final class_5912 resourceManager;
    private final List<Pair<class_5944, Consumer<class_5944>>> shaderList;

    public RegisterShadersEvent(class_5912 resourceManager, List<Pair<class_5944, Consumer<class_5944>>> shaderList) {
        this.resourceManager = resourceManager;
        this.shaderList = shaderList;
    }

    public class_5912 getResourceManager() {
        return resourceManager;
    }

    public void registerShader(class_5944 shaderInstance, Consumer<class_5944> onLoaded) {
        shaderList.add(Pair.of(shaderInstance, onLoaded));
    }
}