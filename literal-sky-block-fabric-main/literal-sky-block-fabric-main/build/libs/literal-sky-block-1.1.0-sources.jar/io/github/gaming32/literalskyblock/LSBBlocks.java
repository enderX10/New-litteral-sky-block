package io.github.gaming32.literalskyblock;

import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_7923;

public class LSBBlocks {
    public static final class_2248 SKY_BLOCK = class_2378.method_10230(
            class_7923.field_41175,
            class_2960.method_60655(LiteralSkyBlock.MOD_ID, "sky_block"),
            new SkyBlock(
                    class_4970.class_2251.method_9630(class_2246.field_10340)
                            .method_26235((blockState, blockGetter, blockPos, object) -> false)
                            .method_26236((blockState, blockGetter, blockPos) -> false)
                            .method_26243((blockState, blockGetter, blockPos) -> false)
                            .method_9631(state -> state.method_11654(SkyBlock.ACTIVE) ? 15 : 0)
            )
    );
    public static final class_2248 VOID_BLOCK = class_2378.method_10230(
            class_7923.field_41175,
            class_2960.method_60655(LiteralSkyBlock.MOD_ID, "void_block"),
            new VoidBlock(
                    class_4970.class_2251.method_9630(class_2246.field_10340)
            )
    );
    public static final class_2248 VANTA_BLACK = class_2378.method_10230(
            class_7923.field_41175,
            class_2960.method_60655(LiteralSkyBlock.MOD_ID, "vanta_black"),
            new class_2248(
                    class_4970.class_2251.method_9630(class_2246.field_10340)
            )
    );

    static void register() {}
}