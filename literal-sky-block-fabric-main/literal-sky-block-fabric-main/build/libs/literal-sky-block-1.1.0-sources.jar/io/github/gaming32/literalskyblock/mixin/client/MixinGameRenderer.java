package io.github.gaming32.literalskyblock.mixin.client;

import com.mojang.datafixers.util.Pair;
import io.github.gaming32.literalskyblock.client.LSBClient;
import io.github.gaming32.literalskyblock.forge.RegisterShadersEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.io.IOException;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_5912;
import net.minecraft.class_5944;
import net.minecraft.class_757;

@Mixin(class_757.class)
public class MixinGameRenderer {
    @Unique
    private class_5912 forge$resourceManager;

    @Inject(method = "reloadShaders", at = @At("HEAD"))
    private void storeResourceManager(class_5912 manager, CallbackInfo ci) {
        forge$resourceManager = manager;
    }

    @Redirect(
            method = "reloadShaders",
            at = @At(
                    value = "INVOKE",
                    target = "Ljava/util/List;add(Ljava/lang/Object;)Z"
            )
    )
    private boolean implementShadersEvent(List<Pair<class_5944, Consumer<class_5944>>> instance, Object e) throws IOException {
        @SuppressWarnings("unchecked")
        final var shader = (Pair<class_5944, Consumer<class_5944>>)e;
        instance.add(shader);
        if (shader.getFirst().method_35787().equals("rendertype_crumbling")) {
            LSBClient.registerShaders(new RegisterShadersEvent(forge$resourceManager, instance));
        }
        return true;
    }
}