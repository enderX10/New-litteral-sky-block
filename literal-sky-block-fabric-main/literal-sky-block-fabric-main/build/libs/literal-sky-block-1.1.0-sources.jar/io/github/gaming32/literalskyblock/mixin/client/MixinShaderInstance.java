package io.github.gaming32.literalskyblock.mixin.client;

import io.github.gaming32.literalskyblock.forge.HackShaderInstanceResourceLocation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.io.FileNotFoundException;
import net.minecraft.class_2960;
import net.minecraft.class_3298;
import net.minecraft.class_5912;
import net.minecraft.class_5944;

@Mixin(class_5944.class)
public class MixinShaderInstance {
    @ModifyVariable(method = "<init>", at = @At("STORE"), ordinal = 0)
    private class_2960 changeResourceLocationInit(class_2960 value) {
        final String namespace = HackShaderInstanceResourceLocation.namespace.get();
        if (namespace != null) {
            value = class_2960.method_60655(namespace, value.method_12832());
        }
        return value;
    }

    @Redirect(
            method = "getOrCreate",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/server/packs/resources/ResourceProvider;getResourceOrThrow(Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/server/packs/resources/Resource;"
            )
    )
    private static class_3298 changeResourceLocationGetOrCreate(class_5912 instance, class_2960 resourceLocation) throws FileNotFoundException {
        final String namespace = HackShaderInstanceResourceLocation.namespace.get();
        if (namespace != null) {
            resourceLocation = class_2960.method_60655(namespace, resourceLocation.method_12832());
        }
        return instance.getResourceOrThrow(resourceLocation);
    }
}