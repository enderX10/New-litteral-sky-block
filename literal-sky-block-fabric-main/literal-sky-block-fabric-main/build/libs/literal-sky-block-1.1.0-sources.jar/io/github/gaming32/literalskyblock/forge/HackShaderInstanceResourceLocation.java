package io.github.gaming32.literalskyblock.forge;

import java.io.IOException;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_5912;
import net.minecraft.class_5944;

public class HackShaderInstanceResourceLocation {
    public static ThreadLocal<String> namespace = new ThreadLocal<>();

    public static class_5944 create(class_5912 factory, class_2960 resourceLocation, class_293 format) throws IOException {
        namespace.set(resourceLocation.method_12836());
        final class_5944 result = new class_5944(factory, resourceLocation.method_12832(), format);
        namespace.set(null);
        return result;
    }
}
