package io.github.gaming32.literalskyblock;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import org.jetbrains.annotations.Nullable;

public class VoidBlock extends SkyBlock {
    public VoidBlock(class_2251 properties) {
        super(properties);
    }

    @Override
    protected MapCodec<? extends VoidBlock> method_53969() {
        return method_54094(VoidBlock::new);
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new VoidBlockEntity(pos, state);
    }
}