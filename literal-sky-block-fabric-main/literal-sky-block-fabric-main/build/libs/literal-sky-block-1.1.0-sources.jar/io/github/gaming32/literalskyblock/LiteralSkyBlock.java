package io.github.gaming32.literalskyblock;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_7706;

public class LiteralSkyBlock implements ModInitializer {
    public static final String MOD_ID = "literalskyblock";

    @Override
    public void onInitialize() {
        LSBBlocks.register();
        LSBItems.register();
        LSBBlockEntities.register();

        // Dodawanie do zakładki w 1.21
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40197).register(content -> {
            content.method_45421(LSBItems.SKY_BLOCK);
            content.method_45421(LSBItems.VOID_BLOCK);
            content.method_45421(LSBItems.VANTA_BLACK);
        });
    }
}