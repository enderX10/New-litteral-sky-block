package io.github.gaming32.literalskyblock.client;

import com.mojang.blaze3d.systems.RenderSystem;
import org.joml.Matrix4f;
import io.github.gaming32.literalskyblock.LSBBlockEntities;
import io.github.gaming32.literalskyblock.LiteralSkyBlock;
import io.github.gaming32.literalskyblock.forge.HackShaderInstanceResourceLocation;
import io.github.gaming32.literalskyblock.forge.RegisterShadersEvent;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1041;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_276;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4063;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4668;
import net.minecraft.class_5616;
import net.minecraft.class_5944;
import net.minecraft.class_6367;
import net.minecraft.class_757;
import net.minecraft.class_758;
import net.minecraft.class_761;
import net.minecraft.class_765;
import net.minecraft.class_9779;
import net.minecraft.client.renderer.*;
import java.io.IOException;

import static org.lwjgl.opengl.GL11.GL_COLOR_BUFFER_BIT;
import static org.lwjgl.opengl.GL11.GL_DEPTH_BUFFER_BIT;

@Environment(EnvType.CLIENT)
public class LSBClient implements ClientModInitializer {
    private static class_5944 skyShader;
    private static int skyWidth = -1;
    private static int skyHeight = -1;
    private static class_6367 skyRenderTarget;
    public static boolean updateSky = false;
    private static boolean isRenderingSky = false;
    static boolean needIrisCompat;

    public static class_5944 getSkyShader() {
        return skyShader;
    }

    public static void setSkyShader(class_5944 shader) {
        skyShader = shader;
    }

    public static final class_1921 SKY_RENDER_TYPE = class_1921.method_24049(LiteralSkyBlock.MOD_ID + "_sky", class_290.field_1592, class_293.class_5596.field_27382, 256, false, false, class_1921.class_4688.method_23598()
            .method_34578(new class_4668.class_5942(LSBClient::getSkyShader))
            .method_34577(new class_4668.class_5939(
                    () -> {
                        if (skyRenderTarget != null) {
                            RenderSystem.setShaderTexture(0, skyRenderTarget.method_30277());
                        } else {
                            RenderSystem.setShaderTexture(0, 0);
                        }
                    },
                    () -> {}
            ))
            .method_23617(false)
    );

    public static void renderSky(WorldRenderContext event) {
        if (isRenderingSky) return;

        final class_310 mc = class_310.method_1551();
        final class_1041 window = mc.method_22683();
        final int ww = window.method_4489();
        final int wh = window.method_4506();

        if (ww <= 0 || wh <= 0) return;

        boolean update = false;

        if (skyRenderTarget == null || skyWidth != ww || skyHeight != wh) {
            update = true;
            skyWidth = ww;
            skyHeight = wh;
        }

        if (update) {
            if (skyRenderTarget != null) {
                skyRenderTarget.method_1238();
            }
            skyRenderTarget = new class_6367(skyWidth, skyHeight, true, class_310.field_1703);
        }

        if (needIrisCompat && IrisCompat.shadersEnabled()) {
            return;
        }
        if (needIrisCompat) IrisCompat.preRender(mc.field_1769);

        mc.field_1769.method_35774();
        skyRenderTarget.method_1235(true);

        isRenderingSky = true;
        final class_276 mainRenderTarget = mc.method_1522();
        renderActualSky(mc, event);
        isRenderingSky = false;

        skyRenderTarget.method_1242();
        skyRenderTarget.method_1240();
        mc.field_1769.method_35774();
        mainRenderTarget.method_1235(true);
        if (needIrisCompat) IrisCompat.postRender(mc.field_1769);
    }

    public static void renderActualSky(class_310 mc, WorldRenderContext event) {
        final class_4587 poseStack = event.matrixStack();
        final class_9779 deltaTracker = event.tickCounter();
        final float delta = deltaTracker.method_60636();
        final Matrix4f projectionMatrix = event.projectionMatrix();
        final Matrix4f positionMatrix = event.positionMatrix();
        final class_761 levelRenderer = mc.field_1769;
        final LevelRendererLSB levelRendererLSB = (LevelRendererLSB)levelRenderer;
        final class_757 gameRenderer = mc.field_1773;
        final class_4184 camera = gameRenderer.method_19418();
        final class_243 cameraPos = camera.method_19326();
        final class_765 lightTexture = gameRenderer.method_22974();

        class_758.method_3210(camera, delta, mc.field_1687, mc.field_1690.method_38521(), gameRenderer.method_3195(delta));
        class_758.method_3212();
        RenderSystem.clear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT, class_310.field_1703);
        final float renderDistance = gameRenderer.method_3193();
        final boolean hasSpecialFog = mc.field_1687.method_28103().method_28110(class_3532.method_15357(cameraPos.field_1352), class_3532.method_15357(cameraPos.field_1351)) || mc.field_1705.method_1740().method_1800();

        RenderSystem.setShader(class_757::method_34539);

        levelRenderer.method_3257(positionMatrix, projectionMatrix, delta, camera, false, () -> class_758.method_3211(camera, class_758.class_4596.field_20945, renderDistance, hasSpecialFog, delta));

        // Zastąpiono przestarzały RenderSystem.getModelViewStack() bezpośrednią obsługą PoseStack
        poseStack.method_22903();
        poseStack.method_23760().method_23761().mul(poseStack.method_23760().method_23761());

        if (mc.field_1690.method_42528().method_41753() != class_4063.field_18162) {
            // Zmieniono na poprawną nazwę shadera w 1.21
            RenderSystem.setShader(class_757::method_34543);
            RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
            levelRenderer.method_3259(poseStack, positionMatrix, projectionMatrix, delta, cameraPos.field_1352, cameraPos.field_1351, cameraPos.field_1350);
        }

        RenderSystem.depthMask(false);
        levelRendererLSB.renderSnowAndRainLSB(lightTexture, delta, cameraPos.field_1352, cameraPos.field_1351, cameraPos.field_1350);
        RenderSystem.depthMask(true);

        RenderSystem.disableBlend();
        poseStack.method_22909();

        class_758.method_23792();
    }

    @Override
    public void onInitializeClient() {
        needIrisCompat = FabricLoader.getInstance().isModLoaded("iris");
        WorldRenderEvents.END.register(LSBClient::renderSky);
        class_5616.method_32144(LSBBlockEntities.SKY_BLOCK, SkyBlockEntityRenderer::new);
        class_5616.method_32144(LSBBlockEntities.VOID_BLOCK, SkyBlockEntityRenderer::new);
    }

    public static void registerShaders(RegisterShadersEvent event) throws IOException {
        event.registerShader(HackShaderInstanceResourceLocation.create(event.getResourceManager(), class_2960.method_60655(LiteralSkyBlock.MOD_ID, "sky"), class_290.field_1592), LSBClient::setSkyShader);
    }
}