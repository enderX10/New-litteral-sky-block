package io.github.gaming32.literalskyblock;

import java.util.Arrays;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;

public class SkyBlockEntity extends class_2586 {
    private final Boolean[] shouldRender = new Boolean[6];

    public SkyBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
        super(type, pos, state);
    }

    public SkyBlockEntity(class_2338 pos, class_2680 state) {
        this(LSBBlockEntities.SKY_BLOCK, pos, state);
    }

    public boolean shouldRenderFace(class_2350 direction) {
        final int index = direction.ordinal();

        if (shouldRender[index] == null) {
            shouldRender[index] = field_11863 == null || class_2248.method_9607(method_11010(), field_11863, method_11016(), direction, method_11016().method_10093(direction));
        }

        return shouldRender[index];
    }

    public void neighborChanged() {
        Arrays.fill(shouldRender, null);
    }
}
