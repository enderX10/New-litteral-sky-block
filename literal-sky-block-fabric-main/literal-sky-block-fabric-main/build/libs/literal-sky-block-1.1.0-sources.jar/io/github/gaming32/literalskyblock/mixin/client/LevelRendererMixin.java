package io.github.gaming32.literalskyblock.mixin.client;

import io.github.gaming32.literalskyblock.client.LSBClient;
import io.github.gaming32.literalskyblock.client.LevelRendererLSB;
import net.minecraft.class_4184;
import net.minecraft.class_4599;
import net.minecraft.class_757;
import net.minecraft.class_761;
import net.minecraft.class_765;
import net.minecraft.class_9779;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_761.class)
public abstract class LevelRendererMixin implements LevelRendererLSB {
    @Shadow @Final private class_4599 renderBuffers;

    // Możliwe, że sygnatura renderSnowAndRain uległa drobnej zmianie w najnowszym Mojmapie 1.21.
    // W razie błędu kompilacji dostosuj typy do tych, które wskaże Twój IDE.
    @Shadow protected abstract void renderSnowAndRain(class_765 manager, float f, double d, double e, double g);

    @Inject(
            method = "renderLevel",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/renderer/MultiBufferSource$BufferSource;endBatch(Lnet/minecraft/client/renderer/RenderType;)V",
                    ordinal = 6,
                    shift = At.Shift.AFTER
            )
    )
    private void renderLevelLSB(class_9779 deltaTracker, boolean renderBlockOutline, class_4184 camera, class_757 gameRenderer, class_765 lightTexture, Matrix4f frustumMatrix, Matrix4f projectionMatrix, CallbackInfo ci) {
        renderBuffers.method_23000().method_22994(LSBClient.SKY_RENDER_TYPE);
    }

    @Override
    public void renderSnowAndRainLSB(class_765 arg, float g, double d, double e, double h) {
        renderSnowAndRain(arg, g, d, e, h);
    }
}