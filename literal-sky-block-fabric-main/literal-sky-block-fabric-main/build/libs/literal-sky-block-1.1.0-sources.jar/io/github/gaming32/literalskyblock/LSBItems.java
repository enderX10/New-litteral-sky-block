package io.github.gaming32.literalskyblock;

import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class LSBItems {
    public static final class_1792 SKY_BLOCK = class_2378.method_10230(
            class_7923.field_41178,
            class_2960.method_60655(LiteralSkyBlock.MOD_ID, "sky_block"),
            new class_1747(LSBBlocks.SKY_BLOCK, new class_1792.class_1793())
    );
    public static final class_1792 VOID_BLOCK = class_2378.method_10230(
            class_7923.field_41178,
            class_2960.method_60655(LiteralSkyBlock.MOD_ID, "void_block"),
            new class_1747(LSBBlocks.VOID_BLOCK, new class_1792.class_1793())
    );
    public static final class_1792 VANTA_BLACK = class_2378.method_10230(
            class_7923.field_41178,
            class_2960.method_60655(LiteralSkyBlock.MOD_ID, "vanta_black"),
            new class_1747(LSBBlocks.VANTA_BLACK, new class_1792.class_1793())
    );

    static void register() {}
}