package io.github.gaming32.literalskyblock;

import net.minecraft.class_2338;
import net.minecraft.class_2680;

public class VoidBlockEntity extends SkyBlockEntity {
    public VoidBlockEntity(class_2338 pos, class_2680 state) {
        super(LSBBlockEntities.VOID_BLOCK, pos, state);
    }
}
