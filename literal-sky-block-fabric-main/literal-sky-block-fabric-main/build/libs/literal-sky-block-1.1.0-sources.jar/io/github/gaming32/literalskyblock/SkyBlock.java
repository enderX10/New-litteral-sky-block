package io.github.gaming32.literalskyblock;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2746;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class SkyBlock extends class_2237 {
    public static final class_2746 ACTIVE = class_2746.method_11825("active");
    public static final class_2746 POWERED = class_2746.method_11825("powered");

    public SkyBlock(class_2251 properties) {
        super(properties);
        method_9590(method_9564().method_11657(ACTIVE, true).method_11657(POWERED, false));
    }

    // Wymóg Minecraft 1.21: definicja kodeka dla bloku
    @Override
    protected MapCodec<? extends SkyBlock> method_53969() {
        return method_54094(SkyBlock::new);
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        final boolean powered = ctx.method_8045().method_49803(ctx.method_8037());
        return this.method_9564().method_11657(ACTIVE, !powered).method_11657(POWERED, powered);
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new SkyBlockEntity(pos, state);
    }

    @NotNull
    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 level, class_2338 pos, class_2338 neighborPos) {
        final class_2586 blockEntity = level.method_8321(pos);

        if (blockEntity instanceof SkyBlockEntity skyBlockEntity) {
            skyBlockEntity.neighborChanged();
        }

        return super.method_9559(state, direction, neighborState, level, pos, neighborPos);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void method_9612(class_2680 state, class_1937 level, class_2338 pos, class_2248 block, class_2338 fromPos, boolean notify) {
        super.method_9612(state, level, pos, block, fromPos, notify);

        final class_2586 blockEntity = level.method_8321(pos);

        if (blockEntity instanceof SkyBlockEntity skyBlockEntity) {
            skyBlockEntity.neighborChanged();
        }

        if (!level.field_9236) {
            boolean wasPowered = state.method_11654(POWERED);
            if (wasPowered != level.method_49803(pos)) {
                class_2680 newState = state.method_28493(POWERED);
                if (!wasPowered) {
                    newState = newState.method_28493(ACTIVE);
                }
                level.method_8652(pos, newState, 2);
            }
        }
    }

    @Override
    public boolean method_9579(class_2680 state, class_1922 world, class_2338 pos) {
        if (this instanceof VoidBlock) {
            return super.method_9579(state, world, pos);
        }
        return true;
    }

    @Override
    @SuppressWarnings("deprecation")
    public int method_9505(class_2680 state, class_1922 world, class_2338 pos) {
        if (this instanceof VoidBlock) {
            return super.method_9505(state, world, pos);
        }
        return 0;
    }

    @NotNull
    @Override
    public class_2464 method_9604(class_2680 state) {
        return state.method_11654(ACTIVE) ? class_2464.field_11455 : class_2464.field_11458;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(ACTIVE, POWERED);
    }
}