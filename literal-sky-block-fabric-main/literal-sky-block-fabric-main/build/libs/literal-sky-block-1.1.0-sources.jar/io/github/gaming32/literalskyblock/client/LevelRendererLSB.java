package io.github.gaming32.literalskyblock.client;

import net.minecraft.class_765;

public interface LevelRendererLSB {
    void renderSnowAndRainLSB(class_765 arg, float g, double d, double e, double h);
}
