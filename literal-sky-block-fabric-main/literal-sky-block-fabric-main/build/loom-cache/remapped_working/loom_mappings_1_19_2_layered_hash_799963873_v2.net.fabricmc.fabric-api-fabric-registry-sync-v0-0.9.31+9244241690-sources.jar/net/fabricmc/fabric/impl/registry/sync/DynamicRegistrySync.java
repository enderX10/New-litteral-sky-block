/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.registry.sync;

import com.mojang.serialization.Lifecycle;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import net.fabricmc.fabric.api.event.registry.RegistryEntryAddedCallback;
import net.fabricmc.fabric.mixin.registry.sync.RegistryAccessor;
import net.minecraft.core.Registry;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.WritableRegistry;
import net.minecraft.data.BuiltinRegistries;
import net.minecraft.resources.ResourceKey;

/**
 * Handles synchronising changes to the built-in registries into the dynamic registry manager's template manager,
 * in case it gets classloaded early.
 */
public class DynamicRegistrySync {
	private static final Logger LOGGER = LoggerFactory.getLogger(DynamicRegistrySync.class);

	/**
	 * Sets up a synchronisation that will propagate added entries to the given dynamic registry manager, which
	 * should be the <em>built-in</em> manager. It is never destroyed. We don't ever have to unregister
	 * the registry events.
	 */
	public static void setupSync(RegistryAccess template) {
		LOGGER.debug("Setting up synchronisation of new BuiltinRegistries entries to the built-in DynamicRegistryManager");
		BuiltinRegistries.REGISTRY.stream().forEach(source -> setupSync(source, template));
	}

	/**
	 * Sets up an event registration for the source registy that will ensure all entries added from now on
	 * are also added to the template for dynamic registry managers.
	 */
	private static <T> void setupSync(Registry<T> source, RegistryAccess template) {
		@SuppressWarnings("unchecked") RegistryAccessor<T> sourceAccessor = (RegistryAccessor<T>) source;
		ResourceKey<? extends Registry<T>> sourceKey = source.key();
		WritableRegistry<T> target = (WritableRegistry<T>) template.registryOrThrow(sourceKey);

		RegistryEntryAddedCallback.event(source).register((rawId, id, object) -> {
			LOGGER.trace("Synchronizing {} from built-in registry {} into built-in dynamic registry manager template.",
					id, source.key());
			Lifecycle lifecycle = sourceAccessor.callGetEntryLifecycle(object);
			ResourceKey<T> entryKey = ResourceKey.create(sourceKey, id);
			target.registerMapping(rawId, entryKey, object, lifecycle);
		});
	}
}
