/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.resource.loader;

import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import net.fabricmc.fabric.impl.resource.loader.FabricNamespaceResourceManagerEntry;
import net.fabricmc.fabric.impl.resource.loader.FabricResource;
import net.minecraft.server.packs.repository.PackSource;
import net.minecraft.server.packs.resources.FallbackResourceManager;
import net.minecraft.server.packs.resources.Resource;

@Mixin(FallbackResourceManager.SinglePackResourceThunkSupplier.class)
public class NamespaceResourceManagerEntryMixin implements FabricNamespaceResourceManagerEntry {
	@Unique
	private @Nullable PackSource fabric_packSource;

	@Override
	public void setFabricPackSource(PackSource packSource) {
		this.fabric_packSource = packSource;
	}

	@Inject(method = "toReference", at = @At("RETURN"))
	public void toReference(CallbackInfoReturnable<Resource> cir) {
		Resource resource = cir.getReturnValue();
		((FabricResource) resource).setFabricPackSource(fabric_packSource);
	}
}
