/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.resource.loader.client.pack;

import java.io.IOException;
import java.io.InputStream;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;

import org.jetbrains.annotations.Nullable;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.resource.ModResourcePack;
import net.fabricmc.fabric.impl.resource.loader.GroupResourcePack;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.AbstractPackResources;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.metadata.MetadataSectionSerializer;

/**
 * Represents the Programmer Art resource pack with support for modded content.
 *
 * <p>Any vanilla resources are provided like in Vanilla through the original programmer art, any missing resources
 * will be searched in the provided modded resource packs.
 */
@Environment(EnvType.CLIENT)
public class ProgrammerArtResourcePack extends GroupResourcePack {
	private final AbstractPackResources originalResourcePack;

	public ProgrammerArtResourcePack(AbstractPackResources originalResourcePack, List<ModResourcePack> modResourcePacks) {
		super(PackType.CLIENT_RESOURCES, modResourcePacks);
		this.originalResourcePack = originalResourcePack;
	}

	@Override
	public InputStream getRootResource(String fileName) throws IOException {
		if (!fileName.contains("/") && !fileName.contains("\\")) {
			// There should be nothing to read at the root of mod's Programmer Art extensions.
			return this.originalResourcePack.getRootResource(fileName);
		} else {
			throw new IllegalArgumentException("Root resources can only be filenames, not paths (no / allowed!)");
		}
	}

	@Override
	public InputStream getResource(PackType type, ResourceLocation id) throws IOException {
		if (this.originalResourcePack.hasResource(type, id)) {
			return this.originalResourcePack.getResource(type, id);
		}

		return super.getResource(type, id);
	}

	@Override
	public Collection<ResourceLocation> getResources(PackType type, String namespace, String prefix, Predicate<ResourceLocation> predicate) {
		Set<ResourceLocation> resources = new HashSet<>(this.originalResourcePack.getResources(type, namespace, prefix, predicate));

		resources.addAll(super.getResources(type, namespace, prefix, predicate));

		return resources;
	}

	@Override
	public boolean hasResource(PackType type, ResourceLocation id) {
		return this.originalResourcePack.hasResource(type, id) || super.hasResource(type, id);
	}

	@Override
	public Set<String> getNamespaces(PackType type) {
		Set<String> namespaces = this.originalResourcePack.getNamespaces(type);

		namespaces.addAll(super.getNamespaces(type));

		return namespaces;
	}

	@Override
	public <T> @Nullable T getMetadataSection(MetadataSectionSerializer<T> metaReader) throws IOException {
		return this.originalResourcePack.getMetadataSection(metaReader);
	}

	@Override
	public String getName() {
		return "Programmer Art";
	}

	@Override
	public void close() {
		this.originalResourcePack.close();
		super.close();
	}
}
