package net.minecraft.advancements.critereon;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.mojang.serialization.codecs.RecordCodecBuilder.Instance;
import java.util.Optional;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.advancements.Criterion;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.ExtraCodecs;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

public class SlideDownBlockTrigger extends SimpleCriterionTrigger<SlideDownBlockTrigger.TriggerInstance> {
    @Override
    public Codec<SlideDownBlockTrigger.TriggerInstance> codec() {
        return SlideDownBlockTrigger.TriggerInstance.CODEC;
    }

    public void trigger(ServerPlayer p_66979_, BlockState p_66980_) {
        this.trigger(p_66979_, p_66986_ -> p_66986_.matches(p_66980_));
    }

    public static record TriggerInstance(Optional<ContextAwarePredicate> player, Optional<Holder<Block>> block, Optional<StatePropertiesPredicate> state)
        implements SimpleCriterionTrigger.SimpleInstance {
        public static final Codec<SlideDownBlockTrigger.TriggerInstance> CODEC = ExtraCodecs.validate(
            RecordCodecBuilder.create(
                p_311437_ -> p_311437_.group(
                            ExtraCodecs.strictOptionalField(EntityPredicate.ADVANCEMENT_CODEC, "player")
                                .forGetter(SlideDownBlockTrigger.TriggerInstance::player),
                            ExtraCodecs.strictOptionalField(BuiltInRegistries.BLOCK.holderByNameCodec(), "block")
                                .forGetter(SlideDownBlockTrigger.TriggerInstance::block),
                            ExtraCodecs.strictOptionalField(StatePropertiesPredicate.CODEC, "state").forGetter(SlideDownBlockTrigger.TriggerInstance::state)
                        )
                        .apply(p_311437_, SlideDownBlockTrigger.TriggerInstance::new)
            ),
            SlideDownBlockTrigger.TriggerInstance::validate
        );

        private static DataResult<SlideDownBlockTrigger.TriggerInstance> validate(SlideDownBlockTrigger.TriggerInstance p_312038_) {
            return p_312038_.block
                .<DataResult<SlideDownBlockTrigger.TriggerInstance>>flatMap(
                    p_311441_ -> p_312038_.state
                            .<String>flatMap(p_311443_ -> p_311443_.checkState(((Block)p_311441_.value()).getStateDefinition()))
                            .map(p_311445_ -> DataResult.error(() -> "Block" + p_311441_ + " has no property " + p_311445_))
                )
                .orElseGet(() -> DataResult.success(p_312038_));
        }

        public static Criterion<SlideDownBlockTrigger.TriggerInstance> slidesDownBlock(Block p_67007_) {
            return CriteriaTriggers.HONEY_BLOCK_SLIDE
                .createCriterion(new SlideDownBlockTrigger.TriggerInstance(Optional.empty(), Optional.of(p_67007_.builtInRegistryHolder()), Optional.empty()));
        }

        public boolean matches(BlockState p_67009_) {
            if (this.block.isPresent() && !p_67009_.is(this.block.get())) {
                return false;
            } else {
                return !this.state.isPresent() || this.state.get().matches(p_67009_);
            }
        }
    }
}
